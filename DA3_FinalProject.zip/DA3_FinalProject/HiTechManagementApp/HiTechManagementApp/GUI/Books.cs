﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HiTechManagementApp.GUI
{
    public partial class Books : Form
    {
        public Books()
        {
            InitializeComponent();
        }


        private void buttonAdd_Click(object sender, EventArgs e)
        {
            / Book bo = new Book();

            if ((Validator.IsValidId(textBoxISBN.Text, 4)) &&
                 (Validator.IsValidName(Title.Text)) &&
                 (Validator.IsValidName(UnitPrice.Text)) &&
                 //(!(ord.IdExists(Convert.ToInt32(textBoxEmployeeId.Text)))))
            {

                Book.OrderId = Convert.ToInt32(textBoxISBN.Text);
                Book.OrderDate = textBoxTitle.Text;
                Book.SaveOrder(bo);
                MessageBox.Show("Employee Info has been saved successfully.", "Confirmation");

            }
            else
            {
                string input = "";
                input = textBoxISBN.Text.Trim();
                if (!Validator.IsValidId(input, 4))
                {
                    MessageBox.Show("Invalid Order ID!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxISBN.Clear();
                    textBoxISBN;
                }

                // if (ord.IdExists(Convert.ToInt32(input)))
                {
                    MessageBox.Show("Order ID already exists!", "Duplicate Employee ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxISBN.Clear();
                    textBoxISBN.Focus();
                    return;
                }


            }

        }

        private void buttonListAllEmployees_Click(object sender, EventArgs e)
        {
            Book bo = new Book();
            List<Book> listord = bo.GetBookList();
            listViewBook.Items.Clear();

            foreach (Book anord in listord)
            {

                ListViewItem item = new ListViewItem(anord.EmployeeId.ToString());
                item.SubItems.Add(anord.FirstName);
                item.SubItems.Add(anord.LastName);
                item.SubItems.Add(anord.JobTitle);
                listViewBook.Items.Add(item);
            }

        }

        private void buttonSearchEmployee_Click(object sender, EventArgs e)
        {
            //check search Option selected
            if (comboBoxSearchBook.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the search option.", "Missing search option", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //input data validation
            string input = "";
            input = textBoxInput.Text.Trim();
            if (!Validator.IsValidId(input, 4))
            {
                MessageBox.Show("Invalid IBSN", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxInput.Clear();
                textBoxInput.Focus();
                return;
            }
            Book bo = new Book();
            bo = bo.SearchBook(Convert.ToInt32(input));
            if (bo != null)
            {

                textBoxISBN.Text = bo.EmployeeId.ToString();
                textBoxTitle.Text = bo.FirstName;
                textBoxUnitPrice.Text = bo.LastName;


                buttonUpdateBook.Enabled = true;
                buttonDelete.Enabled = true;

            }
            else
            {
                MessageBox.Show("Book not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxInput.Clear();
                textBoxInput.Focus();
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {

        }
    }
}
