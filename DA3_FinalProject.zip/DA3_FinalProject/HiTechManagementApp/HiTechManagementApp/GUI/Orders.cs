﻿using HiTech.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Order;

namespace HiTechManagementApp.GUI
{
    public partial class Orders : Form
    {
        public Orders()
        {
            InitializeComponent();
        }

        
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            /Order ord = new Order();

            if ((Validator.IsValidId(textBoxOrderId.Text, 4)) &&
                 (Validator.IsValidName(textBoxOrderDate.Text)) &&
                 (Validator.IsValidName(textBoxCustomerId.Text))&&
                 //(!(ord.IdExists(Convert.ToInt32(textBoxEmployeeId.Text)))))
            {

                ord.OrderId = Convert.ToInt32(textBoxEmployeeId.Text);
                ord.OrderDate = textBoxFirstName.Text;
                ord.SaveOrder(ord);
                MessageBox.Show("Employee Info has been saved successfully.", "Confirmation");

            }
            else
            {
                string input = "";
                input = textBoxEmployeeId.Text.Trim();
                if (!Validator.IsValidId(input, 4))
                {
                    MessageBox.Show("Invalid Order ID!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxOrderId.Clear();
                    textBoxOrderId.Focus();
                    return;
                }

               // if (ord.IdExists(Convert.ToInt32(input)))
                {
                    MessageBox.Show("Order ID already exists!", "Duplicate Employee ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxOrderId.Clear();
                    textBoxOrderId.Focus();
                    return;
                }


            }
        
        }

        private void buttonListAllEmployees_Click(object sender, EventArgs e)
        {
            Order ord = new Order();
            List<Order> listord = ord.GetEmployeeList();
            listViewOrder.Items.Clear();

            foreach (Order anord in listord)
            {

                ListViewItem item = new ListViewItem(anord.EmployeeId.ToString());
                item.SubItems.Add(anord.FirstName);
                item.SubItems.Add(anord.LastName);
                item.SubItems.Add(anord.JobTitle);
                listViewOrder.Items.Add(item);
            }

        }

        private void buttonSearchEmployee_Click(object sender, EventArgs e)
        {
            //check search Option selected
            if (comboBoxSearchOrder.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the search option.", "Missing search option", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //input data validation
            string input = "";
            input = textBoxInput.Text.Trim();
            if (!Validator.IsValidId(input, 4))
            {
                MessageBox.Show("Invalid Order ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxInput.Clear();
                textBoxInput.Focus();
                return;
            }
            Order ord = new Order();
            ord = ord.SearchEmployee(Convert.ToInt32(input));
            if (ord != null)
            {

                textBoxOrdereId.Text = ord.EmployeeId.ToString();
                textBoxOrderDate.Text = ord.FirstName;
                textBoxPayment.Text = ord.LastName;


                buttonUpdateOrder.Enabled = true;
                buttonDelete.Enabled = true;

            }
            else
            {
                MessageBox.Show("Employee not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxInput.Clear();
                textBoxInput.Focus();
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {

        }
    }
}

