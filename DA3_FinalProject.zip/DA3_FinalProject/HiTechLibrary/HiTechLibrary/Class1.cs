﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions; // use the class Regex
using Microsoft.VisualBasic; // Information.IsNumeric(input)
using HiTech.Business;
using HiTech.DataAccess;
using HiTech.Validation;

namespace HiTech.Business
{
    public class Employee
    {
        private int employeeId;
        private string firstName;
        private string lastName;
        private string jobTitle;

        public int EmployeeId { get => employeeId; set => employeeId = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string JobTitle { get => jobTitle; set => jobTitle = value; }

        public void SaveEmployee(Employee emp)
        {
            EmployeeDB.SaveRecord(emp);
        }

        public Employee SearchEmployee(int empId)
        {
            return EmployeeDB.SearchRecord(empId);

        }
        public bool IdExists(int id)
        {
            return EmployeeDB.IsDuplicateId(id);
        }
        public List<Employee> GetEmployeeList()
        {
            return EmployeeDB.GetAllRecords();
        }


    }


}

namespace HiTech.DataAccess
{
    public static class UtilityDB
    {
        public static SqlConnection ConnectDB()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["connectDB"].ConnectionString;
            conn.Open();
            return conn;
        }


    }

    public static class EmployeeDB
    {
        public static void SaveRecord(Employee emp)
        {
            //1. Connect DB
            SqlConnection conn = UtilityDB.ConnectDB();
            //2. Create and Customize an SqlCommand object
            SqlCommand cmdInsert = new SqlCommand();
            cmdInsert.CommandText = "INSERT INTO Employees (EmployeeId,FirstName,LastName,JobTitle) " +
                                    " VALUES (@EmployeeId,@FirstName,@LastName,@JobTitle)";
            cmdInsert.Parameters.AddWithValue("@EmployeeId", emp.EmployeeId);
            cmdInsert.Parameters.AddWithValue("@FirstName", emp.FirstName);
            cmdInsert.Parameters.AddWithValue("@LastName", emp.LastName);
            cmdInsert.Parameters.AddWithValue("@JobTitle", emp.JobTitle);
            cmdInsert.Connection = conn;
            //3. Perform the INSERT command
            cmdInsert.ExecuteNonQuery();
            //4. Close the DB
            conn.Close();
            conn.Dispose();

        }
        public static Employee SearchRecord(int eId)
        {
            Employee emp = new Employee();

            //1. Connect DB
            SqlConnection conn = UtilityDB.ConnectDB();
            //2. Create and Customize an SqlCommand object
            SqlCommand cmdSearchById = new SqlCommand();
            cmdSearchById.CommandText = "SELECT * FROM Employees WHERE EmployeeId = @EmployeeId";
            cmdSearchById.Connection = conn;
            cmdSearchById.Parameters.AddWithValue("@EmployeeId", eId);
            //3. Perform the SELECT command
            SqlDataReader reader = cmdSearchById.ExecuteReader();
            if (reader.Read())
            {
                emp.EmployeeId = Convert.ToInt32(reader["EmployeeId"]);
                emp.FirstName = reader["FirstName"].ToString();
                emp.LastName = reader["LastName"].ToString();
                emp.JobTitle = reader["JobTitle"].ToString();

            }
            else
            {
                emp = null;
            }
            //4. Close the DB 

            conn.Close();
            conn.Dispose();
            return emp;

        }

        public static bool IsDuplicateId(int eId)
        {
            Employee emp = new Employee();

            //1. Connect DB
            SqlConnection conn = UtilityDB.ConnectDB();
            //2. Create and Customize an SqlCommand object
            SqlCommand cmdSearchById = new SqlCommand();
            cmdSearchById.CommandText = "SELECT * FROM Employees WHERE EmployeeId = @EmployeeId";
            cmdSearchById.Connection = conn;
            cmdSearchById.Parameters.AddWithValue("@EmployeeId", eId);
            //3. Perform the SELECT command
            SqlDataReader reader = cmdSearchById.ExecuteReader();
            if (reader.HasRows)
            {
                return true;

            }
            //4. Close the DB 

            conn.Close();
            conn.Dispose();
            return false;

        }
       public static List<Employee> GetAllRecords()
        {
            List<Employee> listE = new List<Employee>();

            //1. Connect DB
            SqlConnection conn = UtilityDB.ConnectDB();
            //2. Create and Customize an SqlCommand object
            SqlCommand cmdSelect = new SqlCommand("SELECT * fROM Employees ", conn);
            //3. Perform the SELECT command
            SqlDataReader reader = cmdSelect.ExecuteReader();
            Employee emp; // class : reference type

            while (reader.Read())
            {
                emp = new Employee();
                emp.EmployeeId = Convert.ToInt32(reader["EmployeeId"]);
                emp.FirstName = reader["FirstName"].ToString();
                emp.LastName = reader["LastName"].ToString();
                emp.JobTitle = reader["JobTitle"].ToString();
                listE.Add(emp);
            }
            //4. Close the DB 
            conn.Close();
            conn.Dispose();
            return listE;
        }


    }


    


}


namespace HiTech.Validation
{
    public static class Validator
    {
        //Employee ID : 4-digit number
        public static bool IsValidId(string input)
        {
            if (!(Regex.IsMatch(input, @"^\d{4}$")))
            {
                return false;
            }
            return true;
        }

        public static bool IsNumeric(string input)
        {
            if (!Information.IsNumeric(input))
            {
                return false;
            }

            return true;
        }
        public static bool IsValidId(string input, int size)
        {
            if (!(Regex.IsMatch(input, @"^\d{" + size + "}$")))
            {
                return false;
            }
            return true;
        }


        public static bool IsValidName(string input)
        {
            for (int i = 0; i < input.Length; i++)
            {
                if ((!Char.IsLetter(input[i])) && (!Char.IsWhiteSpace(input[i])))
                {
                    return false;
                }
            }

            return true;
        }

    }

}
