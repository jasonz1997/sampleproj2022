﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions; // use the class Regex
using Microsoft.VisualBasic; // Information.IsNumeric(input)
using HiTech.Orders;
using HiTech.DataAccess;
using HiTech.Orders.HiTech.DataAccess;
using HiTech.Validation;

//dataAccess in the library
namespace HiTech.Orders
{
    public class Order
    {
        private int orderId;
        private int orderDate;
        private int payment;


        public int OrderId { get => orderId; set => orderId = value; }
        public int OrderDate { get => orderDate; set => orderDate = value; }
        public int Payment { get => payment; set => payment = value; }


        public void SaveOrder(Order ord)
        {
            OrderDB.SaveRecord(ord);
        }

        public Order SearchOrder(int ordId)
        {
            return OrderDB.SearchRecord(ordId);

        }
        public bool IdExists(int id)
        {
            return OrderDB.IsDuplicateId(id);
        }
        public List<Order> GetOrderList()
        {
            return OrderDB.GetAllRecords();
        }


    }

    namespace HiTech.DataAccess
    {
        public static class OrderDB
        {
            public static void SaveRecord(Order ord)
            {
                //1. Connect DB
                SqlConnection conn = UtilityDB.ConnectDB();
                //2. Create and Customize an SqlCommand object
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.CommandText = "INSERT INTO Orders (OrderId,OrderDate,Payment) " +
                                        " VALUES (@OrderId,@OrderDate,@Payment)";
                cmdInsert.Parameters.AddWithValue("@OrderId", ord.OrderId);
                cmdInsert.Parameters.AddWithValue("@OrderDate", ord.OrderDate);
                cmdInsert.Parameters.AddWithValue("@Payment", ord.Payment);
                cmdInsert.Connection = conn;
                //3. Perform the INSERT command
                cmdInsert.ExecuteNonQuery();
                //4. Close the DB
                conn.Close();
                conn.Dispose();

            }
            public static Order SearchRecord(int oId)
            {
                Order ord = new Order();

                //1. Connect DB
                SqlConnection conn = UtilityDB.ConnectDB();
                //2. Create and Customize an SqlCommand object
                SqlCommand cmdSearchById = new SqlCommand();
                cmdSearchById.CommandText = "SELECT * FROM Orders WHERE OrderId = @OrderId";
                cmdSearchById.Connection = conn;
                cmdSearchById.Parameters.AddWithValue("@OrderId", oId);
                //3. Perform the SELECT command
                SqlDataReader reader = cmdSearchById.ExecuteReader();
                if (reader.Read())
                {
                    ord.OrderId = Convert.ToInt32(reader["OrderId"]);
                    ord.OrderDate = Convert.ToInt32(reader["OrderDate"]);
                    ord.Payment = Convert.ToInt32(reader["Payment"]);


                }
                else
                {
                    ord = null;
                }
                //4. Close the DB 

                conn.Close();
                conn.Dispose();
                return ord;

            }

            public static bool IsDuplicateId(int oId)
            {
                Order ord = new Order();

                //1. Connect DB
                SqlConnection conn = UtilityDB.ConnectDB();
                //2. Create and Customize an SqlCommand object
                SqlCommand cmdSearchById = new SqlCommand();
                cmdSearchById.CommandText = "SELECT * FROM Orders WHERE OrderId = @OrderId";
                cmdSearchById.Connection = conn;
                cmdSearchById.Parameters.AddWithValue("@OrderId", oId);
                //3. Perform the SELECT command
                SqlDataReader reader = cmdSearchById.ExecuteReader();
                if (reader.HasRows)
                {
                    return true;

                }
                //4. Close the DB 

                conn.Close();
                conn.Dispose();
                return false;

            }
            public static List<Order> GetAllRecords()
            {
                List<Order> listE = new List<Order>();

                //1. Connect DB
                SqlConnection conn = UtilityDB.ConnectDB();
                //2. Create and Customize an SqlCommand object
                SqlCommand cmdSelect = new SqlCommand("SELECT * fROM Orders ", conn);
                //3. Perform the SELECT command
                SqlDataReader reader = cmdSelect.ExecuteReader();
                Order ord; // class : reference type

                while (reader.Read())
                {
                    ord = new Order();
                    ord.OrderId = Convert.ToInt32(reader["OrderId"]);
                    ord.OrderDate = Convert.ToInt32(reader["OrderDate"]);
                    ord.Payment = Convert.ToInt32(reader["Payment"]);

                    listE.Add(ord);
                }
                //4. Close the DB 
                conn.Close();
                conn.Dispose();
                return listE;
            }


        }
    }
}


